export interface SmtpConfig {
  host: string;
  port: string;
  username: string;
  password: string;
}
