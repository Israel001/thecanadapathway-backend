export interface FlutterwaveConfig {
  secretKey: string;
  baseUrl: string;
}
