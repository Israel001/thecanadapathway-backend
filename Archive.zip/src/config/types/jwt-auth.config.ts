export interface JwtAuthConfig {
  secretKey: string;
}
